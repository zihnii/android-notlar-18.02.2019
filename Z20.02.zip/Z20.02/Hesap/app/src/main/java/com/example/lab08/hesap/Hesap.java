package com.example.lab08.hesap;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Hesap extends AppCompatActivity {
    View.OnClickListener

    EditText sayi1,sayi2;
    Button btntopla,btncikar,btnbol,btncarp;
    TextView tvsonuc;
    int  deger1,deger2,sonuc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hesap);

        sayi1 = findViewById(R.id.sayi1);
        sayi2 = findViewById(R.id.sayi2);
        tvsonuc = findViewById(R.id.tvsonuc);
        btnbol = findViewById(R.id.btnbol);
        btncarp = findViewById(R.id.btncarp);
        btncikar = findViewById(R.id.btncikar);
        btntopla = findViewById(R.id.btntopla);

        btncikar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deger1 = Integer.parseInt(sayi1.getText().toString());
                deger2 = Integer.parseInt(sayi2.getText().toString());
                sonuc = deger1-deger2;
                tvsonuc.setText("Çıkarma sonucu"+sonuc);

            }
        });
        btncarp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deger1 = Integer.parseInt(sayi1.getText().toString());
                deger2 = Integer.parseInt(sayi2.getText().toString());
                sonuc = deger1*deger2;
                tvsonuc.setText("Çarpma sonucu"+sonuc);

            }
        });
        btnbol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deger1 = Integer.parseInt(sayi1.getText().toString());
                deger2 = Integer.parseInt(sayi2.getText().toString());
                sonuc = deger1/deger2;
                tvsonuc.setText("Bölme sonucu"+sonuc);

            }
        });
        btntopla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deger1 = Integer.parseInt(sayi1.getText().toString());
                deger2 = Integer.parseInt(sayi2.getText().toString());
                sonuc = deger1+deger2;
                tvsonuc.setText("Toplama sonucu"+sonuc);

            }
        });

    }
}
