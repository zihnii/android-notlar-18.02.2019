package com.example.lab08.deneme2002;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Deneme2002 extends AppCompatActivity {

    Button btn1,btn2,btn3,btn4
    TextView tvyazi



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deneme2002);
    }
}
